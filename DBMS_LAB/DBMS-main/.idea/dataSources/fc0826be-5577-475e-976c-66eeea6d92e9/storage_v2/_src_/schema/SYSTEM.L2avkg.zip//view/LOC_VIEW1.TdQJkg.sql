create view LOC_VIEW1 as
select l.ROOMID, l.BUILDING, l.ROOMNO, l.CAPACITY, r.ROOMDESC
    from location l, ROOM R where l.ROOMTYPE=R.ROOMTYPE
/

